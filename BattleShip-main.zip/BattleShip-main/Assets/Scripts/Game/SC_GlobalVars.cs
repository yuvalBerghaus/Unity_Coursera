using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SC_GlobalVars
{
    public static string userId;
    public static int maxTurnTime = 30;
}
