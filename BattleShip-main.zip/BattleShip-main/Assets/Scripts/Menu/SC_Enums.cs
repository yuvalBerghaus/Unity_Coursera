using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SC_Enums : MonoBehaviour 
{
    public enum Screens
    {
        MainMenu, Loading, MultiPlayer, Options, StudentInfo, SinglePlayer
    };
}