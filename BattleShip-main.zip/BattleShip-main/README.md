# BattleShip
Welcome to my Battleship game!

# Game Instruction
Once you start multiplayer/singleplayer game you must first put all your ships in the left side and wait for your turn.
Once the turn goes to you, you must click the ready button.
After that for each turn you must decide which slot you would like to shoot by pressing on the chosen slot.
Have fun!
